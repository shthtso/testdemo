from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def test(request):
    return HttpResponse("<h1>Hello, this is a test message</h1>")
def home(request):
    return render(request, 'demo.html')
def time(request):
    return render(request, 'current_time.html')

